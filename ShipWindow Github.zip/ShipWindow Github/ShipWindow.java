/*
 * P. Cochran and N. Guidry
 * Creating a JFrame object that displays a group of ships to choose from and 
 * displays the selected ships attributes
 * Last Edited: 9/23/22
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.io.*;

public class ShipWindow extends JFrame 
{
    private int win_wid = 650;
    private int win_hei = 240;
    private String flotillaFileName = "Tia_RosasFleet.csv";
    
    JTextField field1 = new JTextField();
    JTextField field2 = new JTextField();
    JTextField field3 = new JTextField(); 
    JTextField field4 = new JTextField();
    JTextField field5 = new JTextField();
    JTextField field6 = new JTextField();
    
    ArrayList<Ship> flotilla;
    
    JComboBox selectShipBox;
    
    public ShipWindow()
    {
        this.setTitle("Shipping News          P.Cochran and N.Guidry");
        this.setSize(win_wid, win_hei);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
        initButtonPan();
        initInfoPanel();
        flotilla = initShips(flotillaFileName);
        initSelectPanel();

        this.setVisible(true);  
    }
    
    private ArrayList initShips(String flotillaFileName)
    {   
        File flotillaFile = new File(flotillaFileName);
        ArrayList<Ship> flotilla = new ArrayList<Ship>();
        
        try{
            Scanner inscan = new Scanner(flotillaFile).useDelimiter("[,\n]");
            if (! flotillaFile.exists())
            {
                String errorMessage = "Error reading file";
                JOptionPane.showMessageDialog(null,errorMessage, "Flotilla file error", 0);
            }
            
            while (inscan.hasNext())
            {
                String shipName = inscan.next();
                String countryName = inscan.next();
                int yearC = inscan.nextInt();
                int lengthW = inscan.nextInt();
                int draftW = inscan.nextInt();
                int beamW = inscan.nextInt();

                Ship tempShip = new Ship(shipName, countryName, yearC, lengthW, 
                        draftW,beamW);
                flotilla.add(tempShip);
            }
        } 
        catch(IOException ioe)
        {
            String errorMessage = "Error reading file";
            JOptionPane.showMessageDialog(null,errorMessage, "Flotilla file error", 0);
        }
        
        return flotilla;
    }
    
    private void initSelectPanel()
    {
        int fontSize = 26;
        Font bigFont = new Font("Arial", 1, fontSize);
        JLabel lab = new JLabel("Select a Ship");
        lab.setFont(bigFont);
        
        selectShipBox = new JComboBox();
        selectShipBox.addItemListener(new ItemListener()
        {
            public void itemStateChanged(ItemEvent ie)
            {
                String shipChosen = (String)ie.getItem();
                for (int index = 0; index < flotilla.size(); index ++)
                {
                    if (shipChosen.equals(flotilla.get(index).getName()))
                    {
                        String waterlineLength = "";
                        String draftLength = "";
                        String yearConstructed = "";
                        String beamLength = "";
                        
                        waterlineLength += flotilla.get(index).getLength();
                        draftLength += flotilla.get(index).getDraft();
                        yearConstructed += flotilla.get(index).getYearBuilt();
                        beamLength += flotilla.get(index).getBeam();
                        
                        field1.setText(flotilla.get(index).getName());
                        field2.setText(waterlineLength);
                        field3.setText(flotilla.get(index).getNation());
                        field4.setText(draftLength);
                        field5.setText(yearConstructed);
                        field6.setText(beamLength);
                        
                        break;
                    }
                }
            }
        });
        ArrayList<String> tempShipList = new ArrayList();
        
        for(int index = 0; index < flotilla.size(); index ++)
        {    
            tempShipList.add(flotilla.get(index).getName());
        }
       
        selectShipBox.setModel(new javax.swing.DefaultComboBoxModel<>(tempShipList.toArray()));
        
        ImageIcon icon = new ImageIcon("Yacht_big.png");
        
        int scalex = 164, scaley = 82; //size of icon within label
        JLabel iconLab = new JLabel()
        {
            public void paintComponent(Graphics g)
            {
                Image img = icon.getImage();
                g.drawImage(img, 0,0, scalex, scaley, this);
            }
        };
        
        iconLab.setPreferredSize(new Dimension(scalex, scaley));
        iconLab.setIcon(icon);
        
        JPanel northPan = new JPanel();
        
        northPan.add(iconLab);
        northPan.add(lab);
        northPan.add(selectShipBox);
        this.add(northPan, BorderLayout.NORTH);
    }
    
    private void initInfoPanel()
    {
        int gridRows = 3;
        int gridCols = 4;
        
        JLabel shipName = new JLabel("Ship Name:");
        JLabel countryReg = new JLabel("Country of Registration:");
        JLabel yearCons = new JLabel("Year of Construction:");
        JLabel lengthWater = new JLabel("Length at Waterline:");
        JLabel draftWater = new JLabel("Draft at Waterline:");
        JLabel beamWater = new JLabel("Beam at Waterline:");
        
        JPanel centerPan = new JPanel(new GridLayout(gridRows,gridCols));
                
        centerPan.add(shipName);
        centerPan.add(field1);
        centerPan.add(lengthWater);
        centerPan.add(field2);
        centerPan.add(countryReg);
        centerPan.add(field3);
        centerPan.add(draftWater);
        centerPan.add(field4);
        centerPan.add(yearCons);
        centerPan.add(field5);
        centerPan.add(beamWater);
        centerPan.add(field6);
        
        field1.setHorizontalAlignment(JTextField.CENTER);
        field2.setHorizontalAlignment(JTextField.CENTER);
        field3.setHorizontalAlignment(JTextField.CENTER);
        field4.setHorizontalAlignment(JTextField.CENTER);
        field5.setHorizontalAlignment(JTextField.CENTER);
        field6.setHorizontalAlignment(JTextField.CENTER);
        
        this.add(centerPan, BorderLayout.CENTER);
    }
    
    private void initButtonPan()
    {
        JButton clearBut = new JButton("Clear");
        JButton quitBut = new JButton("Quit");
      
        JPanel southPan = new JPanel();
        
        southPan.add(clearBut);
        southPan.add(quitBut);
        
        quitBut.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae)
            {
                System.exit(0);
            }
        });
        
        clearBut.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae)
            {
                clearTextFields();
            }
        });
        
        this.add(southPan, BorderLayout.SOUTH);
        
    }   
    
    private void clearTextFields()
    {
        field1.setText("");
        field2.setText("");
        field3.setText("");
        field4.setText("");
        field5.setText("");
        field6.setText("");
    }
 
    public static void main(String[] args) 
    {
        ShipWindow aw = new ShipWindow(); 
    }
    
}
